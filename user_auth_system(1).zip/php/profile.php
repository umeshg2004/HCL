<?php
// Define stub classes only if the real extensions are not loaded
// This helps intelephense recognize the classes without affecting runtime behavior
if (!extension_loaded('redis') && !class_exists('Redis', false)) {
    class Redis {
        public function connect($host, $port) {}
        public function get($key) {}
        public function setex($key, $ttl, $value) {}
    }
}

// Check if required extensions are loaded
if (!extension_loaded('redis')) {
    die(json_encode(['success' => false, 'message' => 'Redis extension not loaded']));
}

if (!extension_loaded('mongodb')) {
    die(json_encode(['success' => false, 'message' => 'MongoDB extension not loaded']));
}

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database configurations
$mysql_host = 'localhost';
$mysql_db = 'user_auth';
$mysql_user = 'root';
$mysql_pass = '';

// MongoDB configuration
$mongo_host = 'mongodb://localhost:27017';
$mongo_db = 'user_profiles';

// Redis configuration
$redis_host = '127.0.0.1';
$redis_port = 6379;

try {
    // Connect to MySQL
    $mysql_pdo = new PDO("mysql:host=$mysql_host;dbname=$mysql_db", $mysql_user, $mysql_pass);
    $mysql_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Connect to Redis
    $redis = new \Redis();
    $redis->connect($redis_host, $redis_port);
    
    // Get token from request
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_REQUEST;
    }
    
    $token = $input['token'] ?? '';
    
    // Validate token
    if (empty($token)) {
        echo json_encode(['success' => false, 'message' => 'Session token is required']);
        exit();
    }
    
    // Check if token exists in Redis
    $userId = $redis->get($token);
    
    if (!$userId) {
        echo json_encode(['success' => false, 'message' => 'Invalid session token']);
        exit();
    }
    
    // Handle GET request - fetch profile data
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        try {
            // Connect to MongoDB
            $mongo = new \MongoDB\Driver\Manager($mongo_host);
            
            // Create query to find user profile
            $filter = ['user_id' => $userId];
            $options = [];
            $query = new \MongoDB\Driver\Query($filter, $options);
            
            // Execute query
            $cursor = $mongo->executeQuery("$mongo_db.profiles", $query);
            /** @var \MongoDB\Driver\Cursor $cursor */
            $profiles = $cursor->toArray();
            
            if (count($profiles) > 0) {
                $profile = $profiles[0];
                echo json_encode([
                    'success' => true,
                    'data' => [
                        'age' => $profile->age ?? null,
                        'dob' => $profile->dob ?? null,
                        'contact' => $profile->contact ?? null
                    ]
                ]);
            } else {
                // Return empty profile data if not found
                echo json_encode([
                    'success' => true,
                    'data' => [
                        'age' => null,
                        'dob' => null,
                        'contact' => null
                    ]
                ]);
            }
        } catch (\MongoDB\Driver\Exception\Exception $e) {
            // If MongoDB is not available, return empty profile data
            echo json_encode([
                'success' => true,
                'data' => [
                    'age' => null,
                    'dob' => null,
                    'contact' => null
                ],
                'message' => 'Profile data unavailable (MongoDB not connected)'
            ]);
        }
    }
    // Handle POST request - update profile data
    else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $age = $input['age'] ?? null;
        $dob = $input['dob'] ?? null;
        $contact = $input['contact'] ?? null;
        
        try {
            // Connect to MongoDB
            $mongo = new \MongoDB\Driver\Manager($mongo_host);
            
            // Prepare bulk write operation
            $bulk = new \MongoDB\Driver\BulkWrite;
            
            // Update or insert profile data
            $filter = ['user_id' => $userId];
            $newObj = [
                'user_id' => $userId,
                'age' => $age,
                'dob' => $dob,
                'contact' => $contact
            ];
            
            // Use upsert to create document if it doesn't exist
            $bulk->update($filter, ['$set' => $newObj], ['upsert' => true]);
            
            // Execute bulk write
            $mongo->executeBulkWrite("$mongo_db.profiles", $bulk);
            
            echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
        } catch (\MongoDB\Driver\Exception\Exception $e) {
            // If MongoDB is not available, return an error
            echo json_encode(['success' => false, 'message' => 'Profile update failed (MongoDB not connected)']);
        }
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} catch (\MongoDB\Driver\Exception\Exception $e) {
    echo json_encode(['success' => false, 'message' => 'MongoDB error: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>