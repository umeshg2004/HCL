<?php
// Define stub classes only if the real extensions are not loaded
// This helps intelephense recognize the classes without affecting runtime behavior
if (!extension_loaded('redis') && !class_exists('Redis', false)) {
    class Redis {
        public function connect($host, $port) {}
        public function get($key) {}
        public function setex($key, $ttl, $value) {}
    }
}

// Check if required extensions are loaded
if (!extension_loaded('redis')) {
    die(json_encode(['success' => false, 'message' => 'Redis extension not loaded']));
}

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database configuration
$mysql_host = 'localhost';
$mysql_db = 'user_auth';
$mysql_user = 'root';
$mysql_pass = '';

// Redis configuration
$redis_host = '127.0.0.1';
$redis_port = 6379;

try {
    // Connect to MySQL
    $pdo = new PDO("mysql:host=$mysql_host;dbname=$mysql_db", $mysql_user, $mysql_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Connect to Redis
    $redis = new \Redis();
    $redis->connect($redis_host, $redis_port);
    
    // Get POST data
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }
    
    $email = $input['email'] ?? '';
    $password = $input['password'] ?? '';
    
    // Validate input
    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Email and password are required']);
        exit();
    }
    
    // Find user by email
    $stmt = $pdo->prepare("SELECT id, password FROM users WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        exit();
    }
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Verify password
    if (!password_verify($password, $user['password'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        exit();
    }
    
    // Generate session token
    $token = bin2hex(random_bytes(32));
    
    // Store session in Redis (token => user_id, expire in 1 hour)
    $redis->setex($token, 3600, $user['id']);
    
    echo json_encode(['success' => true, 'message' => 'Login successful', 'token' => $token]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>