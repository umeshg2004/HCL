$(document).ready(function() {
    // Check if user is logged in
    const token = localStorage.getItem('sessionToken');
    
    if (!token) {
        // Redirect to login if no token
        window.location.href = 'login.html';
        return;
    }
    
    // Load user profile data
    loadProfileData(token);
    
    // Handle profile form submission
    $('#profileForm').on('submit', function(e) {
        e.preventDefault();
        
        const age = $('#age').val();
        const dob = $('#dob').val();
        const contact = $('#contact').val();
        
        $.ajax({
            url: 'php/profile.php',
            method: 'POST',
            data: {
                token: token,
                age: age,
                dob: dob,
                contact: contact
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#message').removeClass('error').addClass('success').text(response.message);
                } else {
                    $('#message').removeClass('success').addClass('error').text(response.message);
                }
            },
            error: function() {
                $('#message').removeClass('success').addClass('error').text('An error occurred. Please try again.');
            }
        });
    });
    
    // Handle logout
    $('#logoutBtn').on('click', function() {
        localStorage.removeItem('sessionToken');
        window.location.href = 'login.html';
    });
    
    // Function to load profile data
    function loadProfileData(token) {
        $.ajax({
            url: 'php/profile.php',
            method: 'GET',
            data: {
                token: token
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Populate form with user data
                    $('#age').val(response.data.age || '');
                    $('#dob').val(response.data.dob || '');
                    $('#contact').val(response.data.contact || '');
                } else {
                    $('#message').removeClass('success').addClass('error').text(response.message);
                    // If token is invalid, remove it and redirect to login
                    if (response.message === 'Invalid session token') {
                        localStorage.removeItem('sessionToken');
                        setTimeout(function() {
                            window.location.href = 'login.html';
                        }, 2000);
                    }
                }
            },
            error: function() {
                $('#message').removeClass('success').addClass('error').text('An error occurred. Please try again.');
            }
        });
    }
});