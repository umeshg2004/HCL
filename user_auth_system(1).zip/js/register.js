$(document).ready(function() {
    $('#registerForm').on('submit', function(e) {
        e.preventDefault();
        
        const email = $('#email').val();
        const password = $('#password').val();
        
        $.ajax({
            url: 'php/register.php',
            method: 'POST',
            data: {
                email: email,
                password: password
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#message').removeClass('error').addClass('success').text(response.message);
                    $('#registerForm')[0].reset();
                    // Redirect to login page after successful registration
                    setTimeout(function() {
                        window.location.href = 'login.html';
                    }, 2000);
                } else {
                    $('#message').removeClass('success').addClass('error').text(response.message);
                }
            },
            error: function() {
                $('#message').removeClass('success').addClass('error').text('An error occurred. Please try again.');
            }
        });
    });
});