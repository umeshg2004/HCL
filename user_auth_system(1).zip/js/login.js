$(document).ready(function() {
    $('#loginForm').on('submit', function(e) {
        e.preventDefault();
        
        const email = $('#email').val();
        const password = $('#password').val();
        
        $.ajax({
            url: 'php/login.php',
            method: 'POST',
            data: {
                email: email,
                password: password
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Store session token in localStorage
                    localStorage.setItem('sessionToken', response.token);
                    // Redirect to profile page
                    window.location.href = 'profile.html';
                } else {
                    $('#message').removeClass('success').addClass('error').text(response.message);
                }
            },
            error: function() {
                $('#message').removeClass('success').addClass('error').text('An error occurred. Please try again.');
            }
        });
    });
});